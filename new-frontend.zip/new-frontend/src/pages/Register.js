import React from 'react';
import RegisterForm from '../components/RegisterForm';

const Register = () => (
  <div>
    <h2>Register</h2>
    <RegisterForm />
  </div>
);

export default Register;
