# Home Budget Planner 

In the project directory, you can run:

### `npm start`

